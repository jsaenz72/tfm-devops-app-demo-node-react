import React from 'react';
export default function Home(){
  return (<div><h2>- Bienvenido -</h2><p>Use el menú para navegar: Nueva Factura, Productos, Empresa.</p></div>);
}
